package observer;

public interface InstanceStartedObserver {
	public void instanceStarted();
}
