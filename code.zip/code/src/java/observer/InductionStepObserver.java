package observer;

public interface InductionStepObserver {
	public void nextStep();
}
