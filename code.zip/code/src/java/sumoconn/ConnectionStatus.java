package sumoconn;

public enum ConnectionStatus {
	MAY_OPEN,
	OPEN,
	CLOSED,
	ERROR
}
